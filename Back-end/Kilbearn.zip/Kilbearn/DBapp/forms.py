from django import forms

class Login(formname.Form):
    username=forms.CharField()
    password=forms.CharField()
    email=forms.CharField()

from django.contrib import admin
from DBapp.models import Main, Friends, Details

admin.site.register(Main)
admin.site.register(Friends)
admin.site.register(Details)

from django.apps import AppConfig


class DbappConfig(AppConfig):
    name = 'DBapp'

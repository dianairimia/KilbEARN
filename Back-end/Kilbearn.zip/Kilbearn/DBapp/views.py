from django.shortcuts import render
from django.http import HttpResponse
from DBapp.models import Main, Friends


def index(request):
    val_dict = {'insert_val':"This can be modified with python, in the views.py file in DBapp" }
    return render(request, 'DBapp/index.html', context=val_dict)
